# QA/QC HDPE - Versión Estable

Versión profesional y afinada del sistema de control de calidad para líneas de HDPE. Incluye:
- Registro de uniones.
- Reportes con KPIs y gráficos.
- Exportación a Excel y PDF.
- Filtrado por fecha.
