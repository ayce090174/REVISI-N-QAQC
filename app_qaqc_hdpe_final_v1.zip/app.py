
import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime, time
import os
from io import BytesIO
from fpdf import FPDF

st.set_page_config(layout="wide")
st.sidebar.title("Navegación")
seccion = st.sidebar.radio("Ir a:", ["Ingreso", "Reportes", "Exportar"])

csv_path = "registros_hdpe.csv"

def cargar_datos():
    if os.path.exists(csv_path):
        return pd.read_csv(csv_path, sep=";", encoding="utf-8-sig")
    else:
        return pd.DataFrame(columns=["Fecha", "Hora", "Operador", "Máquina", "Unión", "Estado", "Observaciones"])

def guardar_datos(df):
    df.to_csv(csv_path, index=False, encoding="utf-8-sig", sep=";")

df = cargar_datos()

if seccion == "Ingreso":
    with st.form("registro_form"):
        st.subheader("📋 Ingreso de Uniones Múltiples")
        fecha = st.date_input("Fecha", datetime.today())
        operador = st.text_input("Operador")
        maquina = st.text_input("Máquina")
        cantidad_uniones = st.number_input("Cantidad de uniones", min_value=1, max_value=50, value=1)

        registros = []
        for i in range(cantidad_uniones):
            st.markdown("---")
            st.subheader(f"Unión #{i+1}")
            col1, col2, col3 = st.columns(3)
            with col1:
                hora = st.time_input(f"Hora unión #{i+1}", value=time(8, 0), key=f"hora_{i}", step=60)
            with col2:
                estado = st.selectbox(f"Estado unión #{i+1}", ["Aprobado", "Rechazado", "Observado"], key=f"estado_{i}")
            with col3:
                observacion = st.text_input(f"Observación #{i+1}", key=f"obs_{i}")

            if operador and maquina:
                registros.append({
                    "Fecha": fecha.strftime("%Y-%m-%d"),
                    "Hora": hora.strftime("%H:%M"),
                    "Operador": operador,
                    "Máquina": maquina,
                    "Unión": 1,
                    "Estado": estado,
                    "Observaciones": observacion
                })

        submitted = st.form_submit_button("Registrar")
        if submitted and registros:
            df = pd.concat([df, pd.DataFrame(registros)], ignore_index=True)
            guardar_datos(df)
            st.success(f"✅ {len(registros)} uniones registradas exitosamente.")
            st.experimental_rerun()

if seccion == "Reportes":
    st.subheader("📋 Registros")
    fecha_filtro = st.date_input("Filtrar por fecha:", datetime.today())
    df_filtrado = df[df["Fecha"] == fecha_filtro.strftime("%Y-%m-%d")]
    st.dataframe(df_filtrado)

    if st.button("🗑 Eliminar todos los registros filtrados"):
        df = df[df["Fecha"] != fecha_filtro.strftime("%Y-%m-%d")]
        guardar_datos(df)
        st.success("✅ Registros eliminados.")
        st.experimental_rerun()

    st.subheader("📊 Indicadores")
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("Total de uniones", int(df["Unión"].astype(int).sum()) if not df.empty else 0)
    with col2:
        st.metric("Aprobadas", int((df["Estado"] == "Aprobado").sum()) if not df.empty else 0)
    with col3:
        st.metric("Rechazadas / Observadas", int((df["Estado"] != "Aprobado").sum()) if not df.empty else 0)

    if not df.empty:
        def crear_grafico(data, col, title, color):
            fig, ax = plt.subplots()
            data.plot(kind="bar", ax=ax, color=color)
            ax.set_title(title)
            return fig

        st.subheader("📈 Producción por Operador")
        st.pyplot(crear_grafico(df.groupby("Operador")["Unión"].sum(), "Operador", "Producción por Operador", "green"))

        st.subheader("📉 Producción por Máquina")
        st.pyplot(crear_grafico(df.groupby("Máquina")["Unión"].sum(), "Máquina", "Producción por Máquina", "blue"))

        st.subheader("🕒 Producción por Hora")
        st.pyplot(crear_grafico(df.groupby("Hora")["Unión"].sum().sort_index(), "Hora", "Producción por Hora", "purple"))

        st.subheader("📊 Distribución por Estado")
        fig4, ax4 = plt.subplots()
        df["Estado"].value_counts().plot(kind="pie", autopct="%1.1f%%", ax=ax4)
        ax4.set_ylabel("")
        ax4.set_title("Distribución de Estados")
        st.pyplot(fig4)

if seccion == "Exportar":
    st.subheader("📤 Exportar Datos")
    buffer = BytesIO()
    df.to_csv(buffer, index=False, encoding="utf-8-sig", sep=";")
    buffer.seek(0)
    st.download_button("📥 Descargar Excel", data=buffer, file_name="registro_hdpe.csv", mime="text/csv")

    class PDF(FPDF):
        def header(self):
            self.set_font("Arial", "B", 12)
            self.cell(0, 10, "Reporte QA/QC HDPE", ln=True, align="C")
            self.ln(10)

    if st.button("📄 Descargar PDF con KPIs y Gráficos"):
        pdf = PDF()
        pdf.add_page()
        pdf.set_font("Arial", size=12)
        pdf.cell(0, 10, f"Total de uniones: {int(df['Unión'].astype(int).sum())}", ln=True)
        pdf.cell(0, 10, f"Aprobadas: {df[df['Estado'] == 'Aprobado'].shape[0]}", ln=True)
        pdf.cell(0, 10, f"Rechazadas/Observadas: {df[df['Estado'].isin(['Rechazado','Observado'])].shape[0]}", ln=True)
        pdf.ln(10)

        for name, data, color in [
            ("Producción por Operador", df.groupby("Operador")["Unión"].sum(), "green"),
            ("Producción por Máquina", df.groupby("Máquina")["Unión"].sum(), "blue"),
            ("Producción por Hora", df.groupby("Hora")["Unión"].sum().sort_index(), "purple"),
            ("Distribución de Estados", df["Estado"].value_counts(), "orange")
        ]:
            fig, ax = plt.subplots()
            if name == "Distribución de Estados":
                data.plot(kind="pie", autopct="%1.1f%%", ax=ax)
                ax.set_ylabel("")
            else:
                data.plot(kind="bar", ax=ax, color=color)
            ax.set_title(name)
            img_buffer = BytesIO()
            fig.savefig(img_buffer, format="png")
            plt.close(fig)
            img_buffer.seek(0)
            pdf.image(img_buffer, x=10, w=180)
            pdf.ln(10)

        pdf_bytes = pdf.output(dest='S').encode('latin1')
        st.download_button("⬇️ Descargar PDF", data=pdf_bytes, file_name="reporte_hdpe.pdf", mime="application/pdf")
    