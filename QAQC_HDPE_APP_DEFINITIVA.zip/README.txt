App QA/QC HDPE - Versión Definitiva

Instrucciones de uso:
1. Hacer doble clic en QAQC_HDPE_FINAL.exe
2. Ingresar los datos completos en el formulario
3. Navegar por los reportes y exportar Excel o PDF

Incluye todos los campos solicitados por Alberto:
- N° Certificado Operador
- Registro Calibración
- Tipo de Unión
- T° Plato Calefactor
- Tipo Ensayo Destructivo
- Por Ejecutar (m)
- Y todos los ya existentes
